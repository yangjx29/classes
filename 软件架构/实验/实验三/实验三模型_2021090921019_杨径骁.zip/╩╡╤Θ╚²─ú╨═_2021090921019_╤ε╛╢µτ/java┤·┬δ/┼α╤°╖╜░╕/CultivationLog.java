/***********************************************************************
 * Module:  CultivationLog.java
 * Author:  yjx
 * Purpose: Defines the Class CultivationLog
 ***********************************************************************/

import java.util.*;

/** @pdOid dd706096-d515-4782-a4d9-aaf599feb0c4 */
public class CultivationLog {
   /** @pdOid 22fbe0a9-c7b0-4a5f-8d6c-c6678a81e105 */
   private Date operateTime;
   /** @pdOid 486fbf09-1400-4164-822a-0392109eec98 */
   private int operatorId;
   /** @pdOid eda1abc1-0605-4190-8320-d37428b9f415 */
   private int detail;
   
   /** @pdOid 23997916-2f08-4453-89ab-dc7f72971d53 */
   public String getDetail() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid bfb0fbf2-7a06-4dc1-b3d9-d0d8072c637f */
   public Date getTime() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid f4f03a04-eef5-495b-83b8-6e92c926ac80 */
   public int getId() {
      // TODO: implement
      return 0;
   }

}