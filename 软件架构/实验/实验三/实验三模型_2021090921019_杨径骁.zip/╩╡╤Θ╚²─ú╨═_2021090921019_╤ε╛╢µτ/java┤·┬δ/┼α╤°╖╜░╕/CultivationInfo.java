/***********************************************************************
 * Module:  CultivationInfo.java
 * Author:  yjx
 * Purpose: Defines the Class CultivationInfo
 ***********************************************************************/

import java.util.*;

/** @pdOid 6e6d525c-33e2-40b3-a0fc-1f2372bfbbd5 */
public class CultivationInfo {
   /** @pdOid 59051b0d-a9ff-4c69-ac07-4dc3de760478 */
   public int cultivationId;
   /** @pdOid 1fa72efa-55f5-4fc3-a832-7b6e55bc7ed6 */
   public String cultivationDetail;
   
   /** @pdOid ed93a71d-d693-42c8-acc1-d5dee0f8768a */
   public int viewCultivationInfo() {
      // TODO: implement
      return 0;
   }
   
   /** @pdOid b20c0d8a-5abb-4c55-9066-b8a6f4698076 */
   public void showDetail() {
      // TODO: implement
   }

}