/***********************************************************************
 * Module:  Account.java
 * Author:  yjx
 * Purpose: Defines the Class Account
 ***********************************************************************/

import java.util.*;

/** @pdOid 849b69e0-f3ce-4eeb-b883-221d098e2ab2 */
public class Account {
   /** @pdOid 64eb432c-fe41-4468-9856-d8cfc7cd0d83 */
   private int account;
   /** @pdOid 0109aac9-ccd1-4e2a-b66c-4d860b794a79 */
   private String password;
   /** @pdOid 272c7039-b5af-4d06-8992-717fb6dfeab3 */
   private int permission;
   
   /** @pdOid ab6bbbde-2113-46b4-9101-e4ec064c4adb */
   public int id;
   
   /** @pdOid bfe8494b-5a60-494e-b3b7-76ef54022a51 */
   public int opearator() {
      // TODO: implement
      return 0;
   }

}