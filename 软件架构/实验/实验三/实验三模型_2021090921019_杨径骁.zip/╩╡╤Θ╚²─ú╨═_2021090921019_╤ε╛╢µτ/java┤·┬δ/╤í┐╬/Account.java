/***********************************************************************
 * Module:  Account.java
 * Author:  yjx
 * Purpose: Defines the Class Account
 ***********************************************************************/

import java.util.*;

/** @pdOid d4d6c53a-048c-448d-8de1-2814c3aa4b50 */
public class Account {
   /** @pdOid 688045a6-ac54-41c5-80b8-c446cae43a0f */
   private int account;
   /** @pdOid 69320aa4-35b4-4294-81dc-f891dc816200 */
   private String password;
   /** @pdOid 2fc29cb7-fd03-4d61-8f64-282f82696beb */
   private int permission;
   
   /** @pdOid 838496fb-e7e7-4fcf-b3d3-b3b54ba1c647 */
   public int id;
   
   /** @pdOid 8e83457b-d658-4ff7-9431-2827e2e00bac */
   public int opearator() {
      // TODO: implement
      return 0;
   }

}