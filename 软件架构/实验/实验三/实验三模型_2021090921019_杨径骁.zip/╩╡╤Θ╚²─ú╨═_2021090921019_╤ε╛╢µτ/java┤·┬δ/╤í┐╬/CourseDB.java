/***********************************************************************
 * Module:  CourseDB.java
 * Author:  yjx
 * Purpose: Defines the Class CourseDB
 ***********************************************************************/

import java.util.*;

/** @pdOid fc2ef517-4e30-414e-84db-e7851ad23f69 */
public class CourseDB {
   /** @pdOid a08dafd4-61a6-4b09-a730-7071d0b64fd1 */
   private int data;
   
   /** @pdOid 1ed571d9-a3c7-4811-9946-da6ef2ed7878 */
   public int operatorDate() {
      // TODO: implement
      return 0;
   }

}