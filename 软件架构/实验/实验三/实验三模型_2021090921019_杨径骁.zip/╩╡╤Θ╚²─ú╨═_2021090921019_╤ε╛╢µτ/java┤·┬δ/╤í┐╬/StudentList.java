/***********************************************************************
 * Module:  StudentList.java
 * Author:  yjx
 * Purpose: Defines the Class StudentList
 ***********************************************************************/

import java.util.*;

/** @pdOid 071dcd5d-f2df-4352-b4df-7c0aa13a254f */
public class StudentList {
   /** @pdOid 3aba0b5c-1d47-4b8b-b3d5-f3acc6e7ce68 */
   public int studentNum;
   /** @pdOid 0cfb7fe0-406d-4967-be39-65fcabbc4cfc */
   public int studentName;
   /** @pdOid 32e4f2f5-19ec-41b8-a653-f5e447342d4f */
   public int department;
   /** @pdOid 81103269-34f0-4f45-aaba-a6cd8ad7469a */
   public int credit;
   
   /** @pdOid d0f52c13-7d5e-43af-878c-dd6f2cecb55d */
   public String getDetail() {
      // TODO: implement
      return null;
   }

}