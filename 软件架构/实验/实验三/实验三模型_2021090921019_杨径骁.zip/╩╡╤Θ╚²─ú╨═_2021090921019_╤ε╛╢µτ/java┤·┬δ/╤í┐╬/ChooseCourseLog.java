/***********************************************************************
 * Module:  ChooseCourseLog.java
 * Author:  yjx
 * Purpose: Defines the Class ChooseCourseLog
 ***********************************************************************/

import java.util.*;

/** @pdOid 562b1fdc-a440-4d22-bb05-46182fa55667 */
public class ChooseCourseLog {
   /** @pdOid b0bcda25-7263-472e-a0fe-0b5dcf687365 */
   private Date operateTime;
   /** @pdOid 5fac813d-d974-4bdb-a23f-70b22179c3cf */
   private int operatorId;
   /** @pdOid a8029105-b512-4cff-9ff3-00e02d3dd740 */
   private int detail;
   
   /** @pdOid b71dc574-8cfc-4ba8-b950-b69f541f4abe */
   public String getDetail() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid f706c3ed-4003-4b17-bdca-f0f620872ce0 */
   public Date getTime() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 7a2b0d02-fbcc-4907-ac79-39c83e2be77f */
   public int getId() {
      // TODO: implement
      return 0;
   }

}