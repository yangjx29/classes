/***********************************************************************
 * Module:  Account.java
 * Author:  yjx
 * Purpose: Defines the Class Account
 ***********************************************************************/

import java.util.*;

/** @pdOid bafbc5c9-b94d-4b28-a7be-6a2d5fb7c3fb */
public class Account {
   /** @pdOid 3fa02625-e731-47c3-ae84-5adf6c6c4979 */
   private int account;
   /** @pdOid 1563b4c7-707f-4fbb-8986-9cb5f2606243 */
   private String password;
   /** @pdOid 864d7452-765c-4ed3-b635-47ef0810a420 */
   private int permission;
   
   /** @pdOid 90b23e0f-6a98-415f-aace-4cde33de9ad1 */
   public int id;
   
   /** @pdOid 2bc92650-c01f-4242-b697-cbf9e27b801b */
   public int opearator() {
      // TODO: implement
      return 0;
   }

}