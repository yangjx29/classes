/***********************************************************************
 * Module:  QuitCourseLog.java
 * Author:  yjx
 * Purpose: Defines the Class QuitCourseLog
 ***********************************************************************/

import java.util.*;

/** @pdOid 261f22c7-3edf-471f-ac3c-5eb60dd00ed1 */
public class QuitCourseLog {
   /** @pdOid 25b58c80-cefd-4d8a-96a0-9b737c7efc71 */
   private Date operateTime;
   /** @pdOid 9af422da-ee7c-4606-a461-b82dcc69f4f2 */
   private int operatorId;
   /** @pdOid eda18d2f-ba4e-4f1a-bf36-016226a03417 */
   private int detail;
   
   /** @pdOid 592fc052-4502-4ba0-9fbe-4c8c00f3033b */
   public String getDetail() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 5031d9bf-ae27-4c68-a2e8-74cedaafe1ea */
   public Date getTime() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid ad177dec-c0a4-4d65-b6f4-16d27d13bf92 */
   public int getId() {
      // TODO: implement
      return 0;
   }

}