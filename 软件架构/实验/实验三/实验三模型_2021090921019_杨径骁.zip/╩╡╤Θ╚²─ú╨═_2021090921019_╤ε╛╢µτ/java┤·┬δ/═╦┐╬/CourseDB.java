/***********************************************************************
 * Module:  CourseDB.java
 * Author:  yjx
 * Purpose: Defines the Class CourseDB
 ***********************************************************************/

import java.util.*;

/** @pdOid 06154d41-8354-4535-9ac8-1f0b00b246ce */
public class CourseDB {
   /** @pdOid cf8fd20e-3844-46a5-a163-374723d46af9 */
   private int data;
   
   /** @pdOid 8a1718de-253c-4ad3-803b-0c760fa7da29 */
   public int operatorDate() {
      // TODO: implement
      return 0;
   }
   
   /** @pdOid 18b202a2-4aaa-46f0-8099-5c2459bd978d */
   public void deleteData() {
      // TODO: implement
   }

}