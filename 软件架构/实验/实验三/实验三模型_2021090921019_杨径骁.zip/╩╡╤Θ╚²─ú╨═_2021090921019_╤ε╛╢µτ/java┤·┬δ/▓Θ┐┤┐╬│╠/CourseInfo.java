/***********************************************************************
 * Module:  CourseInfo.java
 * Author:  yjx
 * Purpose: Defines the Class CourseInfo
 ***********************************************************************/

import java.util.*;

/** @pdOid 88afeb12-21ce-4eb6-bc46-c8360591bfa7 */
public class CourseInfo {
   /** @pdOid 11657fa1-5a02-4e43-ac62-f1895adeae21 */
   public int courseId;
   /** @pdOid 1c7f4231-baef-43db-80a0-69946b6b6b20 */
   public String courseDetail;
   
   /** @pdOid a08aad81-df10-4e68-8a8b-7f4abc83d0f1 */
   public int viewCourseInfo() {
      // TODO: implement
      return 0;
   }
   
   /** @pdOid 935135fd-4a53-47cb-8a47-54e4ae4fae16 */
   public void showDetail() {
      // TODO: implement
   }

}