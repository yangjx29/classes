/***********************************************************************
 * Module:  CourseDB.java
 * Author:  yjx
 * Purpose: Defines the Class CourseDB
 ***********************************************************************/

import java.util.*;

/** @pdOid b8b7f7df-b3dc-4204-8c5b-89e56c716e9d */
public class CourseDB {
   /** @pdOid 4998f6b8-9bda-445c-80e7-253fb39f7dcc */
   private int data;
   
   /** @pdOid d07535ed-5e55-4112-ade2-2e741a6ee9ba */
   public int operatorDate() {
      // TODO: implement
      return 0;
   }
   
   /** @pdOid 9aca84cd-9822-4b04-986c-b3411efab91d */
   public void deleteData() {
      // TODO: implement
   }

}