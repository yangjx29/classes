/***********************************************************************
 * Module:  SelectLog.java
 * Author:  yjx
 * Purpose: Defines the Class SelectLog
 ***********************************************************************/

import java.util.*;

/** @pdOid 4c79e346-a5c6-41f7-a424-b92bf97572c6 */
public class SelectLog {
   /** @pdOid e2dd27cb-2509-4c64-9634-9c7fd07b50ba */
   public int logId;
   /** @pdOid e2a8673f-7355-4ffb-8834-694839fbfa48 */
   public Date operatorTime;
   /** @pdOid 2a9dff0d-8f79-433d-909d-b4b76f6891cb */
   public int data;
   
   /** @pdOid f2ae127e-2bfb-44ff-bd80-cf3362136b79 */
   public String getDetail() {
      // TODO: implement
      return null;
   }

}