/***********************************************************************
 * Module:  StudentList.java
 * Author:  yjx
 * Purpose: Defines the Class StudentList
 ***********************************************************************/

import java.util.*;

/** @pdOid 769ccf31-810e-42b4-b856-ef6a61d25f64 */
public class StudentList {
   /** @pdOid 28483ac6-8c38-4ac0-b8e4-c60edc37ad7f */
   public int studentNum;
   /** @pdOid 772f2666-6cdc-4ac0-9e62-e7d725bc1635 */
   public int studentName;
   /** @pdOid bbe17c21-a7bd-4a96-8472-4f6463e2886f */
   public int department;
   /** @pdOid ede3eb3f-8b73-4bba-9596-e3e8ca980cda */
   public int credit;
   
   /** @pdOid aac83b25-5ffe-41ba-8cf0-0c52913fa8a7 */
   public String getDetail() {
      // TODO: implement
      return null;
   }

}